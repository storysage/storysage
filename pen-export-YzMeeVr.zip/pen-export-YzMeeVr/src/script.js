document.addEventListener('DOMContentLoaded', function() {
    // Load saved tasks from local storage
    var savedTasks = JSON.parse(localStorage.getItem('tasks')) || [];
    savedTasks.forEach(function(task) {
        addTaskToUI(task);
    });

    // Event listener for form submission
    document.getElementById('taskForm').addEventListener('submit', function(event) {
        event.preventDefault();
        var taskName = document.getElementById('taskName').value;
        var taskDescription = document.getElementById('taskDescription').value;
        var taskDueDate = document.getElementById('taskDueDate').value;
        var taskPriority = document.getElementById('taskPriority').value;

        // Create task object
        var task = {
            name: taskName,
            description: taskDescription,
            dueDate: taskDueDate,
            priority: taskPriority,
            id: Date.now() // Generate unique ID for each task
        };

        // Add task to UI
        addTaskToUI(task);

        // Save task to local storage
        savedTasks.push(task);
        localStorage.setItem('tasks', JSON.stringify(savedTasks));

        // Clear form fields
        document.getElementById('taskForm').reset();
    });

    // Function to add task to UI
    function addTaskToUI(task) {
        var taskList = document.getElementById('taskList');
        var taskItem = document.createElement('div');
        taskItem.classList.add('taskItem');
        taskItem.innerHTML = `
            <h3>${task.name}</h3>
            <p><strong>Description:</strong> ${task.description}</p>
            <p><strong>Due Date:</strong> ${task.dueDate}</p>
            <p><strong>Priority:</strong> ${task.priority}</p>
            <button class="closeBtn" data-task-id="${task.id}">Close</button>
        `;
        taskList.appendChild(taskItem);

        // Add event listener to close button
        taskItem.querySelector('.closeBtn').addEventListener('click', function() {
            removeTask(task.id);
            taskList.removeChild(taskItem);
        });
    }

    // Function to remove task from local storage
    function removeTask(taskId) {
        savedTasks = savedTasks.filter(task => task.id !== taskId);
        localStorage.setItem('tasks', JSON.stringify(savedTasks));
    }
});
